// función clickClack(limit){...}

// que reciba un numero entero positivo llamado "limit"
// e imprima para cada número entre 1 y limit:

// - Si el número es divisible entre 5: "Click"
// - Si el número es divisible entre 3: "Clack"
// - Si es divisible entre 5 y entre 3: "ClickClack"
// - Si no es divisible entre 5 ni entre 7: el número tal cual

// Ejemplo de salida para "limit = 15"
// 1
// 2
// Clack
// 4
// Click
// Clack
// 7
// 8
// Clack
// Click
// 11
// Clack
// 13
// 14
// ClickClack
