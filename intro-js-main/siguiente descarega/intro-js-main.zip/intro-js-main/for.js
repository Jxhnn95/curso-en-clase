let indice = 0;

while (indice <= 10) {
  console.log({ indice });
  indice++;
}

// equivalente al código de arriba
// más adecuado y legible para recorrer listas
for (let indice = 0; indice <= 10; indice++) {
  console.log({ indice });
}
