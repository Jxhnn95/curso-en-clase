
public class Multiplicar {

	public static void main(String[] args) {
		
		// 1. Calcular tabla de multiplicar del 5
		
//		5 x 0 = 0
//		5 x 1 = 5
//		5 x 2 = 10
//		...
		
		// 2. Calcular tablas de multiplicar del 1 al 9

	}

}
