export const clientes = [
  {
    id: 1,
    idGestor: 12,
    correo: 'ejemplo@correo.com',
    password: 'unapass',
    usuario: 'Paco',
    saldo: 10.52,
  },
  {
    id: 2,
    idGestor: 12,
    correo: 'ana@correo.com',
    password: 'unapass',
    usuario: 'Ana',
    saldo: 100,
  },
];
