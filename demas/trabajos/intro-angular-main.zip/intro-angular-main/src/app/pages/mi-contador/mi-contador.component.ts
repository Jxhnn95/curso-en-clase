import { Component } from '@angular/core';

@Component({
  selector: 'app-mi-contador',
  templateUrl: './mi-contador.component.html',
  styleUrls: ['./mi-contador.component.css']
})
export class MiContadorComponent {

}
