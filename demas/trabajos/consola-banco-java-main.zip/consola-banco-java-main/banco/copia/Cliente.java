package banco.copia;

public class Cliente{

	public Cliente() {
		
	}

}
