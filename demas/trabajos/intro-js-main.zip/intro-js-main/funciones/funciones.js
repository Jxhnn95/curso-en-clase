// Código no reutilizable
let num1 = 5;
let num2 = 10;

let suma = num1 + num2;

console.log(suma); // Debería imprimir 15

// Convertir en una función

function sum(a, b) {
  return a + b;
}

// Llamada a la función

console.log(sum(num1, num2));

// Llamada a la función con otros argumentos
console.log(sum(10, 20));
