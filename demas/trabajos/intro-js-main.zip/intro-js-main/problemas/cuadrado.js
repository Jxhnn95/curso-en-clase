// función printCuadrado(lado){...}

// que recibe un número entero positivo
// y dibuja con un emoji (Ej. 🟥) un cuadrado del tamaño de lado

// ejemplo para "lado = 1"

// 🟥

// ejemplo para "lado = 10"

// 🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
// 🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
// 🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
// 🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
// 🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
// 🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
// 🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
// 🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
// 🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
// 🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
