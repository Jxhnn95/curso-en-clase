package com.banco.bancobackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BancoBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BancoBackendApplication.class, args);
	}

}
