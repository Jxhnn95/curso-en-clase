package com.banco.bancobackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancoBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
